# APOCALYPSE FIELD NODE (Pi Zero 2 W)

Offline-first survival + civilization knowledge base with strict source trust controls.

## Design goals

- **Offline usable**: markdown corpus + local SQLite FTS index
- **Trustable**: only government/academic/official manuals/peer-reviewed sources
- **Fast**: field search via SQLite FTS5 on low-power hardware
- **Extensible**: add entries safely with schema/validator workflow

## Current status

- Source registry seeded with authoritative sources across L1-L5
- Seed entries created across all layers
- Validator enforces source policy + required safety metadata
- Search index builder creates `index/fieldnode.db`

## Quick start

```bash
cd apocalypse-field-node
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# 1) Generate seed entries
python tools/seed_entries.py

# 2) Validate trust + structure
python tools/validate.py

# 3) Build SQLite search index
python tools/build_index.py
```

## Optional: fetch source snapshots

This is best-effort because some sources are page collections or require manual download/auth:

```bash
python tools/fetch_sources.py --limit 10
```

Then manually place missing PDFs/HTML into `data/sources/snapshots/` and fill SHA-256 values in `data/sources/source_registry.yaml`.

## Offline search example

```bash
sqlite3 index/fieldnode.db \
  "SELECT id,title,category FROM entries_fts WHERE entries_fts MATCH 'tourniquet OR hemorrhage' LIMIT 10;"
```

## Layer taxonomy

- **L1 Immediate Survival**: medical, water, fire, shelter
- **L2 Food & Biology**: plants, mushrooms, tracking/field dressing/preservation
- **L3 Materials & Elements**: wood science, minerals, chemistry
- **L4 Tools & Rebuilding**: tool making, electricity, agriculture
- **L5 Civilization Memory**: math, engineering, governance, communication, navigation

## Entry format

Each entry contains:

- title/category/tags
- region relevance
- step-by-step instructions
- warnings
- related entries
- sources + last verified + confidence

## Pi Zero 2 W optimization notes

- Prefer SQLite + markdown over heavy vector DBs
- Batch source downloads (`--limit`) to avoid memory spikes
- Keep entries concise and linked through `related_entries`
- Use `journal_mode=WAL` (already set in builder)

## Next expansion plan

1. Add hundreds of species records (plants/mushrooms) with strict lookalike fields
2. Add region packs (PNW, Southwest, Northern Europe, etc.)
3. Add a lightweight CLI query tool for glovebox-style prompt lookup
4. Add nightly integrity check job (hash/source staleness)
5. Add compressed export bundle (`tar.zst`) for SD-card deployment
