---
id: l1-fire-friction-methods
title: Friction Fire Methods
category: L1_immediate_survival
subtopic: fire
tags:
- bow-drill
- hand-drill
- fire-plough
- friction
region_relevance:
- global
summary: 'Starting fire using friction-based methods: bow drill, hand drill, and fire
  plough.'
steps:
- 'Bow drill: carve fireboard, spindle, handhold, and bow from dry wood.'
- Cut V-notch in fireboard; place tinder bundle beneath notch.
- Wrap bow string around spindle; press handhold on top, saw bow back and forth.
- 'Hand drill: roll straight, dry spindle between palms on fireboard — requires sustained
  effort.'
- 'Fire plough: rub hardwood shaft along groove in softer wood baseboard.'
- Once ember forms in tinder bundle, gently blow into flame.
warnings:
- Friction fire requires completely dry materials — nearly impossible in wet conditions.
- Hand drill method causes palm blisters — protect hands.
- Practice these techniques before a survival situation — failure rate is high for
  beginners.
related_entries:
- l1-fire-ignition-methods
- l1-fire-tinder-identification
- l1-fire-wood-selection
sources:
- bsa-handbook
- nols-wilderness-guide
- us-army-fm-4-25-11
last_verified: '2026-02-18'
confidence: high
offline_assets: []
---

## Overview
Starting fire using friction-based methods: bow drill, hand drill, and fire plough.

## Step-by-step
1. Bow drill: carve fireboard, spindle, handhold, and bow from dry wood.
2. Cut V-notch in fireboard; place tinder bundle beneath notch.
3. Wrap bow string around spindle; press handhold on top, saw bow back and forth.
4. Hand drill: roll straight, dry spindle between palms on fireboard — requires sustained effort.
5. Fire plough: rub hardwood shaft along groove in softer wood baseboard.
6. Once ember forms in tinder bundle, gently blow into flame.

## Warnings
- Friction fire requires completely dry materials — nearly impossible in wet conditions.
- Hand drill method causes palm blisters — protect hands.
- Practice these techniques before a survival situation — failure rate is high for beginners.
